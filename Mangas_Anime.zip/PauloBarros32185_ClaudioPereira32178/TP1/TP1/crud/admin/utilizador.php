<?php
require_once __DIR__ . '/../src/middleware/middleware-administrador.php';
require_once __DIR__ . '/../aplicacao/templates/cabecalho.php';
$titulo = ' - Utilizador';
?>
<body>
    <main>
 <?php
                if (isset($_SESSION['sucesso'])) {
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                    echo $_SESSION['sucesso'] . '<br>';
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
                    unset($_SESSION['sucesso']);
                }
                if (isset($_SESSION['erros'])) {
                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                    foreach ($_SESSION['erros'] as $erro) {
                        echo $erro . '<br>';
                    }
                    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
                    unset($_SESSION['erros']);
                }
                ?>
        <section class="form-section py-4">
            <div class="container mb-5">
                <div class="row justify-content-center">
                    <div class>
                        <div class="bg-white bg-opacity-75 p-5 rounded shadow form-container">
                        <a href="/admin/" class="btn btn-secondary">Voltar</a>
                            <form enctype="multipart/form-data" action="/src/controlador/admin/controlar-utilizador.php" method="post">
                                <div class="mb-3">
                                    <label for="inputNome" class="form-label">Nome</label>
                                    <input type="text" class="form-control" id="inputNome" name="nome" maxlength="100" value="<?= isset($_REQUEST['nome']) ? htmlspecialchars($_REQUEST['nome']) : '' ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="inputApelido" class="form-label">Apelido</label>
                                    <input type="text" class="form-control" id="inputApelido" name="apelido" maxlength="100" value="<?= isset($_REQUEST['apelido']) ? htmlspecialchars($_REQUEST['apelido']) : '' ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="inputNIF" class="form-label">NIF</label>
                                    <input type="tel" class="form-control" id="inputNIF" name="nif" maxlength="9" value="<?= isset($_REQUEST['nif']) ? htmlspecialchars($_REQUEST['nif']) : '' ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="inputTelemovel" class="form-label">Telemóvel</label>
                                    <input type="tel" class="form-control" id="inputTelemovel" name="telemovel" maxlength="9" value="<?= isset($_REQUEST['telemovel']) ? htmlspecialchars($_REQUEST['telemovel']) : '' ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="inputEmail" class="form-label">E-mail</label>
                                    <input type="email" class="form-control" id="inputEmail" name="email" maxlength="255" value="<?= isset($_REQUEST['email']) ? htmlspecialchars($_REQUEST['email']) : '' ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="inputFoto" class="form-label">Foto de Perfil</label>
                                    <input accept="image/*" type="file" class="form-control" id="inputFoto" name="foto">
                                </div>
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="checkAdministrador" name="administrador" <?= isset($_REQUEST['administrador']) && $_REQUEST['administrador'] == true ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="checkAdministrador">Administrador</label>
                                    </div>
                                </div>
                                <input type="hidden" name="id" value="<?= isset($_REQUEST['id']) ? htmlspecialchars($_REQUEST['id']) : '' ?>">
                                <input type="hidden" name="foto" value="<?= isset($_REQUEST['foto']) ? htmlspecialchars($_REQUEST['foto']) : '' ?>">
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-success" name="utilizador" value="<?= isset($_REQUEST['acao']) && $_REQUEST['acao'] == 'atualizar' ? 'atualizar' : 'criar' ?>">Enviar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
<?php
  require_once __DIR__ . '/../aplicacao/templates/rodape.php';
?>
