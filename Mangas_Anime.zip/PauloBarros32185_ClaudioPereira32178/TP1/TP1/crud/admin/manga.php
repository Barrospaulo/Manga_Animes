<?php
// Requisição do middleware para garantir acesso restrito
require_once __DIR__ . '/../src/middleware/middleware-administrador.php';

// Carregamento do cabeçalho padrão com o título
$titulo = ' - Manga';
require_once __DIR__ . '/../aplicacao/templates/cabecalho.php';
?>

<main class="bg-light py-4">
    <div class="container">
        <?php
        // Exibição das mensagens de sucesso e erro vindas do controlador-manga
        if (isset($_SESSION['sucesso'])) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
            echo $_SESSION['sucesso'] . '<br>';
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            unset($_SESSION['sucesso']);
        }
        if (isset($_SESSION['erros'])) {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
            foreach ($_SESSION['erros'] as $erro) {
                echo $erro . '<br>';
            }
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            unset($_SESSION['erros']);
        }
        ?>

        <form enctype="multipart/form-data" action="/src/controlador/admin/controlar-manga.php" method="post" class="form-control py-5">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="inputTitulo" class="form-label">Título</label>
                    <input type="text" class="form-control" id="inputTitulo" name="titulo" maxlength="255" value="<?= isset($_REQUEST['titulo']) ? $_REQUEST['titulo'] : '' ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="inputAutor" class="form-label">Autor</label>
                    <input type="text" class="form-control" id="inputAutor" name="autor" maxlength="100" value="<?= isset($_REQUEST['autor']) ? $_REQUEST['autor'] : '' ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="inputGenero" class="form-label">Género</label>
                    <input type="text" class="form-control" id="inputGenero" name="genero" maxlength="50" value="<?= isset($_REQUEST['genero']) ? $_REQUEST['genero'] : '' ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="inputISBN" class="form-label">ISBN</label>
                    <input type="text" class="form-control" id="inputISBN" name="isbn" maxlength="20" value="<?= isset($_REQUEST['isbn']) ? $_REQUEST['isbn'] : '' ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="inputPaginas" class="form-label">Número de Páginas</label>
                    <input type="number" class="form-control" id="inputPaginas" name="paginas" min="1" value="<?= isset($_REQUEST['paginas']) ? $_REQUEST['paginas'] : '' ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="inputAno" class="form-label">Ano de Lançamento</label>
                    <input type="number" class="form-control" id="inputAno" name="ano" min="1900" max="<?= date('Y') ?>" value="<?= isset($_REQUEST['ano']) ? $_REQUEST['ano'] : '' ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="inputCapa" class="form-label">Capa da Manga</label>
                    <input accept="image/*" type="file" class="form-control" id="inputCapa" name="capa">
                </div>
                <div class="col-12">
                    <label for="inputSinopse" class="form-label">Sinopse</label>
                    <textarea class="form-control" id="inputSinopse" name="sinopse" rows="5" required><?= isset($_REQUEST['sinopse']) ? $_REQUEST['sinopse'] : '' ?></textarea>
                </div>
                <div class="col-12 d-flex justify-content-between align-items-center">
                    <input type="hidden" name="id" value="<?= isset($_REQUEST['id']) ? $_REQUEST['id'] : '' ?>">
                    <input type="hidden" name="capa" value="<?= isset($_REQUEST['capa']) ? $_REQUEST['capa'] : '' ?>">
                    <button type="submit" class="btn btn-success" name="manga" value="<?= isset($_REQUEST['acao']) && $_REQUEST['acao'] == 'atualizar' ? 'atualizar' : 'criar' ?>">Enviar</button>
                    <a href="/../aplicacao/tabela-manga.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Voltar</a>
                </div>
            </div>
        </form>
    </div>
</main>

<?php
// Carregamento do rodapé padrão
require_once __DIR__ . '/../aplicacao/templates/rodape.php';
?>