<?php
# INSERE DADOS DA CONEXÃO COM O PDO
require_once __DIR__ . '/criar-conexao.php';

/**
 * FUNÇÃO RESPONSÁVEL POR CRIAR UM NOVO MANGÁ
 */
function criarManga($pdo, $manga)
{
    $sqlCreate = "INSERT INTO 
    mangas (
        titulo, 
        autor, 
        genero, 
        isbn, 
        paginas, 
        ano, 
        capa, 
        sinopse
    ) 
    VALUES (
        :titulo, 
        :autor, 
        :genero, 
        :isbn, 
        :paginas, 
        :ano, 
        :capa, 
        :sinopse
    )";

    $PDOStatement = $pdo->prepare($sqlCreate);

    $sucesso = $PDOStatement->execute([
        ':titulo' => $manga['titulo'],
        ':autor' => $manga['autor'],
        ':genero' => $manga['genero'],
        ':isbn' => $manga['isbn'],
        ':paginas' => $manga['paginas'],
        ':ano' => $manga['ano'],
        ':capa' => $manga['capa'],
        ':sinopse' => $manga['sinopse']
    ]);

    if ($sucesso) {
        $manga['id'] = $pdo->lastInsertId();
    }

    return $sucesso;
}

/**
 * FUNÇÃO RESPONSÁVEL POR LER UM MANGÁ POR ID
 */
if (!function_exists('lerMangaPorId')) {
    function lerMangaPorId($pdo, $id)
    {
        $PDOStatement = $pdo->prepare('SELECT * FROM mangas WHERE id = ?;');
        $PDOStatement->bindValue(1, $id, PDO::PARAM_INT);
        $PDOStatement->execute();
        return $PDOStatement->fetch(PDO::FETCH_ASSOC); // Usando PDO::FETCH_ASSOC para retornar um array associativo
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR LER UM MANGÁ PELO ISBN
 */
if (!function_exists('lerMangaPorISBN')) {
    function lerMangaPorISBN($pdo, $isbn)
    {
        $PDOStatement = $pdo->prepare('SELECT * FROM mangas WHERE isbn = ? LIMIT 1;');
        $PDOStatement->bindValue(1, $isbn);
        $PDOStatement->execute();
        return $PDOStatement->fetch(PDO::FETCH_ASSOC); // Usando PDO::FETCH_ASSOC para retornar um array associativo
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR RETORNAR TODOS OS MANGÁS
 */
if (!function_exists('lerTodosMangas')) {
    function lerTodosMangas($pdo)
    {
        $PDOStatement = $pdo->query('SELECT * FROM mangas;');
        $mangas = [];
        while ($listaDeMangas = $PDOStatement->fetch(PDO::FETCH_ASSOC)) {
            $mangas[] = $listaDeMangas;
        }
        return $mangas;
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR ATUALIZAR OS DADOS DE UM MANGÁ NO SISTEMA
 */
if (!function_exists('atualizarManga')) {
    function atualizarManga($pdo, $manga)
    {
        $sqlUpdate = "UPDATE  
        mangas SET
            titulo = :titulo, 
            autor = :autor, 
            genero = :genero, 
            isbn = :isbn, 
            paginas = :paginas, 
            ano = :ano, 
            capa = :capa, 
            sinopse = :sinopse
        WHERE id = :id;";

        $PDOStatement = $pdo->prepare($sqlUpdate);

        return $PDOStatement->execute([
            ':id' => $manga['id'],
            ':titulo' => $manga['titulo'],
            ':autor' => $manga['autor'],
            ':genero' => $manga['genero'],
            ':isbn' => $manga['isbn'],
            ':paginas' => $manga['paginas'],
            ':ano' => $manga['ano'],
            ':capa' => $manga['capa'],
            ':sinopse' => $manga['sinopse']
        ]);
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR DELETAR UM MANGÁ DO SISTEMA
 */
if (!function_exists('deletarManga')) {
    function deletarManga($pdo, $id)
    {
        $PDOStatement = $pdo->prepare('DELETE FROM mangas WHERE id = ?;');
        $PDOStatement->bindValue(1, $id, PDO::PARAM_INT);
        return $PDOStatement->execute();
    }
}
?>
