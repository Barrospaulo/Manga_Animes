<?php
# TRATA-SE DE UMA FORMA RÁPIDA PARA REINICIAR O BANCO DE DADOS EM AMBIENTE DE DESENVOLVIMENTO
# ESTE FICHEIRO NÃO DEVE ESTAR DISPONÍVEL EM PRODUÇÃO

# INSERE DADOS DA CONEXÃO COM O PDO UTILIZANDO SQLITE

require __DIR__ . '/criar-conexao.php';

# APAGA TABELA SE ELA EXISTIR
$pdo->exec('DROP TABLE IF EXISTS mangas;');

echo 'Tabela mangas apagada!' . PHP_EOL;

# CRIA A TABELA MANGAS
$pdo->exec(
    'CREATE TABLE mangas (
    id INTEGER PRIMARY KEY, 
    titulo CHAR, 
    autor CHAR, 
    genero CHAR, 
    isbn CHAR, 
    paginas INTEGER, 
    ano INTEGER, 
    capa CHAR NULL, 
    sinopse TEXT NOT NULL
);'
);

echo 'Tabela mangas criada!' . PHP_EOL;

# ABAIXO UM ARRAY SIMULANDO OS DADOS DE UM MANGÁ 
$manga = [
    'titulo' => 'One Piece',
    'autor' => 'Eiichiro Oda',
    'genero' => 'Ação',
    'isbn' => '1234567',
    'paginas' => 200,
    'ano' => 1996,
    'capa' => null,
    'sinopse' => ''
];

# INSERE MANGÁ
$sqlCreate = "INSERT INTO 
    mangas (
        titulo, 
        autor, 
        genero, 
        isbn, 
        paginas, 
        ano, 
        capa, 
        sinopse) 
    VALUES (
        :titulo, 
        :autor, 
        :genero, 
        :isbn, 
        :paginas, 
        :ano, 
        :capa, 
        :sinopse
    )";

# PREPARA A QUERY
$PDOStatement = $GLOBALS['pdo']->prepare($sqlCreate);

# EXECUTA A QUERY RETORNANDO VERDADEIRO SE A CRIAÇÃO FOI FEITA
$sucesso = $PDOStatement->execute([
    ':titulo' => $manga['titulo'],
    ':autor' => $manga['autor'],
    ':genero' => $manga['genero'],
    ':isbn' => $manga['isbn'],
    ':paginas' => $manga['paginas'],
    ':ano' => $manga['ano'],
    ':capa' => $manga['capa'],
    ':sinopse' => $manga['sinopse']
]);

echo 'Mangá padrão criado!';