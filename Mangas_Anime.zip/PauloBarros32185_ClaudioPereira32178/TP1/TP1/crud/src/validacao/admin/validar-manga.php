<?php

function mangaValido($requisicao)
{
    $erros = [];

    foreach ($requisicao as $key => $value) {
        $requisicao[$key] = trim($value);
    }

    // Validando o campo Título
    if (empty($requisicao['titulo']) || strlen($requisicao['titulo']) < 3 || strlen($requisicao['titulo']) > 255) {
        $erros['titulo'] = 'O campo Título não pode estar vazio e deve ter entre 3 e 255 caracteres.';
    }

    // Validando o campo Autor
    if (empty($requisicao['autor']) || strlen($requisicao['autor']) < 3 || strlen($requisicao['autor']) > 255) {
        $erros['autor'] = 'O campo Autor não pode estar vazio e deve ter entre 3 e 255 caracteres.';
    }

    // Validando o campo Gênero
    if (empty($requisicao['genero']) || strlen($requisicao['genero']) < 3 || strlen($requisicao['genero']) > 255) {
        $erros['genero'] = 'O campo Gênero não pode estar vazio e deve ter entre 3 e 255 caracteres.';
    }

    // Validando o campo ISBN
    if (!preg_match('/^\d{13}$/', $requisicao['isbn'])) {
        $erros['isbn'] = 'O campo ISBN deve conter exatamente 13 números.';
    }

    // Validando o campo Páginas
    if (!filter_var($requisicao['paginas'], FILTER_VALIDATE_INT) || $requisicao['paginas'] <= 0) {
        $erros['paginas'] = 'O campo Páginas deve ser um número inteiro positivo.';
    }

    // Validando o campo Ano
    $ano_atual = date('Y');
    if (!filter_var($requisicao['ano'], FILTER_VALIDATE_INT) || $requisicao['ano'] < 1000 || $requisicao['ano'] > $ano_atual) {
        $erros['ano'] = 'O campo Ano deve ser um número inteiro entre 1000 e ' . $ano_atual . '.';
    }

    // Validando o campo Sinopse
    if (empty($requisicao['sinopse']) || strlen($requisicao['sinopse']) < 10) {
        $erros['sinopse'] = 'O campo Sinopse não pode estar vazio e deve ter no mínimo 10 caracteres.';
    }

    // Retornando os erros ou os dados validados
    if (!empty($erros)) {
        return ['invalido' => $erros];
    }

    return $requisicao;
}
