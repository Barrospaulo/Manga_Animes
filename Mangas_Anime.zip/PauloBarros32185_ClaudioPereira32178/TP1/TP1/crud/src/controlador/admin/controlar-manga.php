<?php
####################
### DEPENDÊNCIAS ###
####################
require_once __DIR__ . '/../../infraestrutura/basededados/repositorio-manga.php';
require_once __DIR__ . '/../../validacao/admin/validar-manga.php';
require_once __DIR__ . '/../../auxiliadores/auxiliador.php';
require_once __DIR__ . '/../../infraestrutura/basededados/criar-conexao.php'; // Incluir o arquivo de conexão PDO aqui

session_start(); // Inicie a sessão para utilizar $_SESSION

# Usa a conexão PDO criada em criar-conexao.php
$pdo = $GLOBALS['pdo'];

##############
### VERBOS ###
##############

# VERBOS POST
## CONTROLA A ROTA PARA CRIAÇÃO E ATUALIZAÇÃO DE UM MANGA NA PÁGINA MANGA
if (isset($_POST['manga'])) {

    ## CONTROLA A CRIAÇÃO DE NOVOS MANGAS
    if ($_POST['manga'] == 'criar') {

        # CRIA UM MANGA
        criar($pdo, $_POST);
    }

    ## CONTROLA A ATUALIZAÇÃO DE DADOS DOS MANGAS
    if ($_POST['manga'] == 'atualizar') {

        # ATUALIZA UM MANGA
        atualizar($pdo, $_POST);
    }

    ## CONTROLA A ATUALIZAÇÃO DA IMAGEM DE CAPA DOS MANGAS
    if ($_POST['manga'] == 'capa') {

        # ATUALIZA A CAPA DE UM MANGA
        alterarCapa($pdo, $_POST);
    }
}

# VERBOS GET
## CONTROLA A ROTA PARA O CARREGAMENTO DE UM MANGA NA PÁGINA ATUALIZAR-MANGA
if (isset($_GET['manga'])) {

    ## CONTROLA A ROTA PARA A CRIAÇÃO DE NOVOS MANGAS
    if ($_GET['manga'] == 'atualizar') {

        # RECUPERA DADOS DO MANGA PELO ID RECEBIDO
        $manga = lerMangaPorId($pdo, $_GET['id']); // Alterei para lerMangaPorId

        # CRIA A SESSÃO AÇÃO ATUALIZAR PARA MANIPULAR O BOTÃO DE ENVIO DO FORMULÁRIO MANGA
        $manga['acao'] = 'atualizar';

        # ENVIA PARÂMETROS COM DADOS DO MANGA PARA A PÁGINA MANGA RECUPERAR DADOS PARA MANIPULAR A ALTERAÇÃO
        $params = '?' . http_build_query($manga);

        header('location: /../admin/manga.php' . $params);
        exit; // Termina o script após redirecionamento
    }

    ## CONTROLA A ROTA PARA A EXCLUSÃO DE MANGAS
    if ($_GET['manga'] == 'deletar') {

        # RECUPERA DADOS DO MANGA
        $manga = lerMangaPorId($pdo, $_GET['id']); // Alterei para lerMangaPorId

        # DELETA MANGA
        $sucesso = deletarManga($pdo, $manga['id']);

        # REDIRECIONA UTILIZADOR PARA PÁGINA ADMIN COM MENSAGEM DE SUCCESO
        if ($sucesso) {
            # DEFINE MENSAGEM DE SUCESSO
            $_SESSION['sucesso'] = 'Manga deletado com sucesso!';

            # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
            header('location: /../../../aplicacao/tabela-manga.php');
            exit; // Termina o script após redirecionamento
        }
    }
}

###############
### FUNÇÕES ###
###############

/**
 * FUNÇÃO RESPONSÁVEL POR CRIAR UM NOVO MANGA
 */
function criar($pdo, $requisicao)
{
    # VALIDA DADOS DO MANGA. FICHEIRO VALIDAÇÃO->APLICAÇAO->ADMIN->VALIDAR-MANGA.PHP
    $dados = mangaValido($requisicao);

    # VERIFICA SE EXISTEM ERROS DE VALIDAÇÃO
    if (isset($dados['invalido'])) {

        # RECUPERA MENSAGEM DE ERRO, CASO EXISTA, E COLOCA EM SESSÃO PARA RECUPERANÃO NO FORMULÁRIO MANGA
        $_SESSION['erros'] = $dados['invalido'];

        # RECUPERA DADOS DO FORMULÁRIO PARA RECUPERAR PREENCHIMENTO ANTERIOR
        $params = '?' . http_build_query($requisicao);

        # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
        header('location: /../admin/manga.php' . $params);
        exit; // Termina o script após redirecionamento
    }

    # GUARDA CAPA EM DIRETÓRIO LOCAL (FUNÇÃO LOCAL)
    $dados = guardaCapa($dados);

    # GUARDA MANGA NA BASE DE DADOS (REPOSITÓRIO PDO)
    $sucesso = criarManga($pdo, $dados);

    # REDIRECIONA UTILIZADOR PARA PÁGINA DE REGISTO COM MENSAGEM DE SUCCESO
    if ($sucesso) {

        # DEFINE MENSAGEM DE SUCESSO
        $_SESSION['sucesso'] = 'Manga criado com sucesso!';

        # REDIRECIONA O UTILIZADO PARA A PÁGINA ADMIN
        header('location: /../../../aplicacao/tabela-manga.php');
        exit; // Termina o script após redirecionamento
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR ATUALIZAR UM MANGA
 */
function atualizar($pdo, $requisicao)
{
    # VALIDA DADOS DO MANGA
    $dados = mangaValido($requisicao);

    # VERIFICA SE EXISTEM ERROS DE VALIDAÇÃO
    if (isset($dados['invalido'])) {

        # RECUPERA MENSAGEM DE ERRO, CASO EXISTA
        $_SESSION['erros'] = $dados['invalido'];

        # CRIA A SESSÃO AÇÃO ATUALIZAR PARA MANIPULAR O BOTÃO DE ENVIO DO FORMULÁRIO MANGA
        $_SESSION['acao'] = 'atualizar';

        # RECUPERA DADOS DO FORMULÁRIO PARA RECUPERAR PREENCHIMENTO ANTERIOR
        $params = '?' . http_build_query($requisicao);

        # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
        header('location: /../admin/manga.php' . $params);
        exit; // Termina o script após redirecionamento
    }

    # RECUPERA DADOS DO MANGA
    $manga = lerMangaPorId($pdo, $dados['id']); // Alterei para lerMangaPorId

    # GUARDA CAPA EM DIRETÓRIO LOCAL E APAGA A CAPA ANTIGA ORIUNDA DA REQUISIÇÃO (FUNÇÃO LOCAL)
    if (!empty($_FILES['capa']['name'])) {
        $dados = guardaCapa($dados, $requisicao);
    }

    # ATUALIZA MANGA (REPOSITÓRIO PDO)
    $sucesso = atualizarManga($pdo, $dados);

    # REDIRECIONA UTILIZADOR PARA PÁGINA DE ALTERAÇÃO COM MENSAGEM DE SUCCESO
    if ($sucesso) {

        # DEFINE MENSAGEM DE SUCESSO
        $_SESSION['sucesso'] = 'Manga alterado com sucesso!';

        # DEFINE BOTÃO DE ENVIO DO FORMULÁRIO
        $dados['acao'] = 'atualizar';

        # RECUPERA DADOS DO FORMULÁRIO PARA RECUPERAR PREENCHIMENTO ANTERIOR
        $params = '?' . http_build_query($dados);

        # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
        header('location: /../admin/manga.php' . $params);
        exit; // Termina o script após redirecionamento
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR ATUALIZAR A CAPA DO MANGA
 */
function alterarCapa($pdo, $requisicao)
{
    # VALIDA DADOS DO MANGA (VALIDAÇÃO)
    $dados = capaValida($requisicao);

    # VERIFICA SE EXISTEM ERROS DE VALIDAÇÃO
    if (isset($dados['invalido'])) {

        # RECUPERA MENSAGEM DE ERRO, CASO EXISTA
        $_SESSION['erros'] = $dados['invalido'];

        # RECUPERA DADOS DO FORMULÁRIO PARA RECUPERAR PREENCHIMENTO ANTERIOR
        $params = '?' . http_build_query($requisicao);

        # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
        header('location: /../admin/capa.php' . $params);
        exit; // Termina o script após redirecionamento
    } else {

        # GUARDA CAPA EM DIRETÓRIO LOCAL E APAGA A CAPA ANTIGA ORIUNDA DA REQUISIÇÃO
        if (!empty($_FILES['capa']['name'])) {

            # GUARDA CAPA EM DIRETÓRIO LOCAL
            $dados = guardaCapa($dados, $requisicao);
        }

        # ATUALIZA MANGA
        $sucesso = atualizarCapa($pdo, $dados);

        # REDIRECIONA UTILIZADOR PARA PÁGINA DE ALTERAÇÃO COM MENSAGEM DE SUCCESO
        if ($sucesso) {

            # DEFINE MENSAGEM DE SUCESSO
            $_SESSION['sucesso'] = 'Capa alterada com sucesso!';

            # REDIRECIONA UTILIZADOR COM DADOS DO FORMULÁRIO ANTERIORMENTE PREENCHIDO
            header('location: /../admin/manga.php?id=' . $dados['id']);
            exit; // Termina o script após redirecionamento
        }
    }
}

/**
 * FUNÇÃO RESPONSÁVEL POR GUARDAR A CAPA DO MANGA EM DIRETÓRIO LOCAL
 */
function guardaCapa($dados, $requisicao = null)
{
    # DEFINE DIRETÓRIO
    $diretorio = __DIR__ . '/../../../image/Capas/';

    # OBTÉM EXTENSÃO DA IMAGEM
    $extensao = pathinfo($_FILES['capa']['name'], PATHINFO_EXTENSION);

    # GERA UM NOME UNICO PARA A IMAGEM
    $nomeArquivo = uniqid() . '.' . $extensao;

    # DEFINE O CAMINHO COMPLETO DA IMAGEM
    $caminhoCompleto = $diretorio . $nomeArquivo;

    # MOVE A IMAGEM PARA O DIRETÓRIO LOCAL
    move_uploaded_file($_FILES['capa']['tmp_name'], $caminhoCompleto);

    # REMOVE A CAPA ANTIGA, SE A FUNÇÃO ESTIVER NO CONTEXTO DE ATUALIZAÇÃO
    if ($requisicao) {
        $caminhoAntigo = $diretorio . $requisicao['capa_atual'];
        if (file_exists($caminhoAntigo)) {
            unlink($caminhoAntigo);
        }
    }

    # ATRIBUI O NOME DA NOVA CAPA AO ARRAY DE DADOS
    $dados['capa'] = $nomeArquivo;

    return $dados;
}

/**
 * FUNÇÃO RESPONSÁVEL POR VALIDAR A CAPA DO MANGA
 */
function capaValida($requisicao)
{
    // Implemente a lógica de validação da capa aqui
    // Exemplo básico: verificar tipo de arquivo, tamanho, etc.

    $dados = [];

    // Verificação básica para fins de exemplo
    if ($_FILES['capa']['size'] > 1000000) {
        $dados['invalido']['capa'] = 'A capa deve ter no máximo 1MB.';
    }

    return $dados;
}

/**
 * FUNÇÃO RESPONSÁVEL POR ATUALIZAR A CAPA DO MANGA NO BANCO DE DADOS
 */
function atualizarCapa($pdo, $dados)
{
    // Implemente a lógica de atualização da capa no banco de dados aqui

    // Exemplo básico de como seria a atualização:
    $sql = 'UPDATE mangas SET capa = :capa WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':capa', $dados['capa']);
    $stmt->bindParam(':id', $dados['id']);
    return $stmt->execute();
}

/**
 * FUNÇÃO RESPONSÁVEL POR LER UM MANGA PELO SEU ID
 */
function lerMangaPorId($pdo, $id)
{
    $sql = 'SELECT * FROM mangas WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
