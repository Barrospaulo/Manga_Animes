<?php
# FUNÇÕES AUXILIADORAS
require_once __DIR__ . '/src/middleware/middleware-nao-autenticado.php';
include_once __DIR__ . '/aplicacao/templates/cabecalho.php';
?>
<body>
    <main class="welcome-container">
        <h1 class="welcome-title">Bem vindo a Manga World!</h1>
        <p class="welcome-text"><b>Para aceder a página dos mangas faça login ou registe-se</b></p>
        <div class="d-flex justify-content-center">
            <a href="/aplicacao/login.php"><button class="btn btn-success btn-custom mx-2">Login</button></a>
            <a href="/aplicacao/registo.php"><button class="btn btn-info btn-custom mx-2">Registo</button></a>
        </div>
</main>
</body>
<?php 
include_once __DIR__ . '/aplicacao/templates/rodape.php'; 
?>