<?php
# CARREGA MIDDLEWARE PARA GARANTIR QUE APENAS UTILIZADORES AUTENTICADOS ACESSEM ESTE SÍTIO
require_once __DIR__ . '/../src/middleware/middleware-utilizador.php';

# ACESSA DE FUNÇÕES AUXILIADORAS.
# NOTA: O SÍMBOLO ARROBA SERVE PARA NÃO MOSTRAR MENSAGEM DE WARNING, POIS A FUNÇÃO ABAIXO TAMBÉM INICIA SESSÕES
@require_once __DIR__ . '/../src/auxiliadores/auxiliador.php';

# CARREGA O CABECALHO PADRÃO COM O TÍTULO
$titulo = '- Detalhes do Mangá';
include_once __DIR__ . '/templates/cabecalho.php';

include_once __DIR__ . '/templates/navbar.php';

# INICIALIZA O REPOSITÓRIO
require_once __DIR__ . '/../src/infraestrutura/basededados/repositorio-manga.php';

# Verifica se o ID foi passado via GET
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    die("ID do mangá não especificado.");
}

# CARREGA OS DETALHES DO MANGÁ ESPECÍFICO
$manga = lerMangaPorId($pdo, $id);

if (!$manga) {
    die("Mangá não encontrado para o ID especificado.");
}
?>
<main class="bg-light p-5">
  <section class="py-4">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <!-- Imagem do Mangá -->
          <img src="/image/Capas/<?= $manga['capa'] ?>" class="card-img-top" alt="<?= htmlspecialchars($manga['titulo']) ?>">
        </div>
        <div class="col-md-8">
          <!-- Detalhes do Mangá -->
          <h2><?= htmlspecialchars($manga['titulo']) ?></h2>
          <p><strong>Autor:</strong> <?= htmlspecialchars($manga['autor']) ?></p>
          <p><strong>Gênero:</strong> <?= htmlspecialchars($manga['genero']) ?></p>
          <p><strong>ISBN:</strong> <?= htmlspecialchars($manga['isbn']) ?></p>
          <p><strong>Páginas:</strong> <?= htmlspecialchars($manga['paginas']) ?></p>
          <p><strong>Ano:</strong> <?= htmlspecialchars($manga['ano']) ?></p>
          <p><strong>Sinopse:</strong> <?= htmlspecialchars($manga['sinopse']) ?></p>
          <!-- Botão Voltar -->
          <a href="/index.php?manga=atualizar&id=<?= $manga['id'] ?>" class="btn btn-primary">Voltar</a>
        </div>
      </div>
    </div>
  </section>
</main>
<?php
include_once __DIR__ . '/templates/rodape.php';
?>
