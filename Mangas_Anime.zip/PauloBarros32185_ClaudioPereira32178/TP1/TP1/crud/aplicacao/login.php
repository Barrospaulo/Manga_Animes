<?php
# MIDDLEWARE PARA GARANTIR QUE APENAS UTILIZADORES NÃO AUTENTICADOS VEJAM A PÁGINA DE LOGIN
require_once __DIR__ . '/../src/middleware/middleware-nao-autenticado.php';

# DEFINE O TÍTULO DA PÁGINA
$titulo = ' - Login';

# INICIA CABECALHO
include_once __DIR__ . '/templates/cabecalho.php';
?>
<body class="login">
  <div>
    <main class="login-container p-5">
      <?php
      # MOSTRA AS MENSAGENS DE ERRO CASO LOGIN SEJA INVÁLIDO
      if (isset($_SESSION['erros'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
        foreach ($_SESSION['erros'] as $erro) {
          echo $erro . '<br>';
        }
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>'; # Corrigir o fechamento da div de alerta
        unset($_SESSION['erros']);
      }
      ?>
      <form action="/src/controlador/aplicacao/controlar-autenticacao.php" method="post" class="login-form">
        <h1 class="mb-3 fw-normal login-title">Login</h1>
        <div class="form-floating mb-2">
          <input type="email" class="form-control" id="Email" placeholder="Endereço de Email" name="email" maxlength="255" value="<?= isset($_REQUEST['email']) ? $_REQUEST['email'] : '' ?>">
          <label for="Email">Endereço de Email</label>
        </div>
        <div class="form-floating mb-2 password-wrapper">
          <input type="password" class="form-control" id="palavra_passe" placeholder="Palavra 3Passe" name="palavra_passe" maxlength="255" value="<?= isset($_REQUEST['palavra_passe']) ? $_REQUEST['palavra_passe'] : '' ?>">
          <label for="palavra_passe">Palavra Passe</label>
          <span class="toggle-password">👁️</span>
        </div>
        <div class="checkbox mb-3">
          <label><input type="checkbox" value="lembra-me"> Lembrar-me</label>
        </div>
        <button class="w-100 btn btn-lg btn-success mb-2 btn-login" type="submit" name="utilizador" value="login">Entrar</button>
      </form>
      <a href="/"><button class="w-100 btn btn-lg btn-info btn-back">Voltar</button></a>
    </main>
  </div>
  <script>
    document.querySelector('.toggle-password').addEventListener('click', function () {
      const passwordInput = document.getElementById('palavra_passe');
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      this.textContent = type === 'password' ? '👁️' : '🔒';
    });
  </script>
</body>
<?php
  include_once __DIR__ . '/templates/rodape.php';
?>