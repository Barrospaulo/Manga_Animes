<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" href="/../Style/index.css">
  <link rel="stylesheet" href="/../Style/login.css">
  <link rel="stylesheet" href="/../Style/registo.css">
  <link rel="stylesheet" href="/../Style/tabela-manga.css">
  <link rel="stylesheet" href="/../Style/perfil.css">
  <link rel="stylesheet" href="/../Style/palavra.passe.css">
  <link rel="stylesheet" href="/../Style/aplicacao.css">
  <title>CRUD<?= $titulo ?? NULL ?></title>
</head>
