  <!-- Site footer -->
  <footer class="site-footer footer bg-danger text-white" >
    <div class=" p-4">
      <div class="row">
        <div class="col-sm-12 col-md-6">
          <p>Professores: António José Viana, Marcelo Antunes Fernandes e Wenderson Wanzeller.</p>
          <p>IPVC-ESTG/ Unidade Curricular:Programação Web.</p>
        </div>
      </div>
    </div>
    <div class="p-4">
      <div class="row">
        <div class="col-md-8 col-sm-6">
          <p class="copyright-text">Copyright &copy; 2024 Este trabalho foi realizado por
            <a style="text-decoration: none;" target="_blank">Paulo Barros</a> e <a style="text-decoration: none;" target="_blank">Claudio Pereira</a>
          </p>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

  </div>

  </html>