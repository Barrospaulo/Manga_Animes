<?php
# INICIALIZA O REPOSITÓRIO
require_once __DIR__ . '/../src/infraestrutura/basededados/repositorio-manga.php';

# INSERE DADOS DA CONEXÃO COM O PDO
require_once __DIR__ . '/../src/infraestrutura/basededados/criar-conexao.php';

# MIDDLEWARE PARA GARANTIR QUE APENAS ADMNISTRADORES ACESSEM ESTA PÁGINA
require_once __DIR__ . '/../src/middleware/middleware-administrador.php';

# FAZ O CARREGAMENTO DE TODOS OS MANGÁS PARA MOSTRAR AO ADMINISTRADOR
$mangas = lerTodosMangas($pdo); // Passando $pdo como argumento

# CARREGA O CABECALHO PADRÃO COM O TÍTULO
$titulo = ' - Painel de Administração de Mangas';
require_once __DIR__ . '/../aplicacao/templates/cabecalho.php';
require_once __DIR__ . '/../aplicacao/templates/navbar.php';
?>
<main class="bg-light p-5">
  <section class="py-4">
    <div class="d-flex justify-content">
      <a href="/admin/manga.php"><button class="btn btn-success px-4 me-2">Criar Mangá</button></a>
      <a href="/aplicacao"><button class="btn btn-secondary px-4 me-2">Voltar</button></a>
      <form action="/../src/controlador/aplicacao/controlar-autenticacao.php" method="post">
        <button class="btn btn-danger px-4" type="submit" name="utilizador" value="logout">Fazer Logout</button>
      </form>
    </div>
  </section>
  <section>
    <?php
    # MOSTRA AS MENSAGENS DE SUCESSO E DE ERRO VINDA DO CONTROLADOR-MANGA
    if (isset($_SESSION['sucesso'])) {
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
      echo $_SESSION['sucesso'] . '<br>';
      echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
      unset($_SESSION['sucesso']);
    }
    if (isset($_SESSION['erros'])) {
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
      foreach ($_SESSION['erros'] as $erro) {
        echo $erro . '<br>';
      }
      echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
      unset($_SESSION['erros']);
    }
    ?>
  </section>
  <section>
    <div class="table-responsive">
      <table class="table">
        <thead class="table-secondary">
          <tr>
            <th scope="col">Título</th>
            <th scope="col">Autor</th>
            <th scope="col">Gênero</th>
            <th scope="col">ISBN</th>
            <th scope="col">Páginas</th>
            <th scope="col">Ano</th>
            <th scope="col">Gerenciar</th>
          </tr>
        </thead>
        <tbody>
          <?php
          # VARRE TODOS OS MANGÁS PARA CONSTRUÇÃO DA TABELA
          foreach ($mangas as $manga) {
          ?>
            <tr>
              <th scope="row"><?= $manga['titulo'] ?></th>
              <td><?= $manga['autor'] ?></td>
              <td><?= $manga['genero'] ?></td>
              <td><?= $manga['isbn'] ?></td>
              <td><?= $manga['paginas'] ?></td>
              <td><?= $manga['ano'] ?></td>
              <td>
                <div class="d-flex justify-content">
                  <a href="/../src/controlador/admin/controlar-manga.php?<?= 'manga=atualizar&id=' . $manga['id'] ?>"><button type="button" class="btn btn-primary me-2">Atualizar</button></a>
                  <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#deletarModal<?= $manga['id'] ?>">Deletar</button>
                </div>
              </td>
            </tr>
            <!-- Modal -->
            <div class="modal fade" id="deletarModal<?= $manga['id'] ?>" tabindex="-1" aria-labelledby="deletarModalLabel<?= $manga['id'] ?>" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <h1 class="modal-title fs-5" id="deletarModalLabel<?= $manga['id'] ?>">Deletar Mangá</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    Esta operação não poderá ser desfeita. Tem certeza que deseja deletar este mangá?
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <a href="/../src/controlador/admin/controlar-manga.php?<?= 'manga=deletar&id=' . $manga['id'] ?>"><button type="button" class="btn btn-danger">Confirmar</button></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fim Modal -->
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </section>
</main>
<?php
# CARREGA O RODAPE PADRÃO
require_once __DIR__ . '/../aplicacao/templates/rodape.php';
?>
