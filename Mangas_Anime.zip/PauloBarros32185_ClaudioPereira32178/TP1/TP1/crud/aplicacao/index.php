<?php
# CARREGA MIDDLEWARE PARA GARANTIR QUE APENAS UTILIZADORES AUTENTICADOS ACESSEM ESTE SÍTIO
require_once __DIR__ . '/../src/middleware/middleware-utilizador.php';

# ACESSA DE FUNÇÕES AUXILIADORAS. 
# NOTA: O SÍMBOLO ARROBA SERVE PARA NÃO MOSTRAR MENSAGEM DE WARNING, POIS A FUNÇÃO ABAIXO TAMBÉM INICIA SESSÕES
@require_once __DIR__ . '/../src/auxiliadores/auxiliador.php';

# PROVENIENTE DE FUNÇÕES AUXILIADORAS. CARREGA O UTILIZADOR ATUAL
$utilizador = utilizador();

# CARREGA O CABECALHO PADRÃO COM O TÍTULO
$titulo = '- Aplicação';
include_once __DIR__ . '/templates/cabecalho.php';

include_once __DIR__ . '/templates/navbar.php';

# INICIALIZA O REPOSITÓRIO
require_once __DIR__ . '/../src/infraestrutura/basededados/repositorio-manga.php';

# FAZ O CARREGAMENTO DE TODOS OS MANGÁS PARA MOSTRAR AO ADMINISTRADOR
$mangas = lerTodosMangas($pdo);
?>
<body>
<main class="main-content">
  <section>
    <?php
    # MOSTRA AS MENSAGENS DE SUCESSO E DE ERRO VINDA DO CONTROLADOR-MANGA
    if (isset($_SESSION['sucesso'])) {
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
      echo $_SESSION['sucesso'] . '<br>';
      echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
      unset($_SESSION['sucesso']);
    }
    if (isset($_SESSION['erros'])) {
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
      foreach ($_SESSION['erros'] as $erro) {
        echo $erro . '<br>';
      }
      echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
      unset($_SESSION['erros']);
    }
    ?>
  </section>
  <section>
    <div class="container">
      <div class="row">
        <?php
        # VARRE TODOS OS MANGÁS PARA CONSTRUÇÃO DOS CARDS
        foreach ($mangas as $manga) {
        ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100">
              <img src="/image/Capas/<?= $manga['capa'] ?>" class="card-img-top" alt="<?= htmlspecialchars($manga['titulo']) ?>">
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($manga['titulo']) ?></h5>
                <div class="d-flex justify-content">
                  <a href="/aplicacao/detalhes-manga.php?id=<?= $manga['id'] ?>" class="btn btn-primary">Ver mais</a>
                </div>
              </div>
            </div>
          </div>
        <?php
        }
        ?>
      </div>
    </div>
  </section>
</main>
</body>
<?php
include_once __DIR__ . '/templates/rodape.php';
?>
